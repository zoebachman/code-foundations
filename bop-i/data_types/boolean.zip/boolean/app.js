$(document).ready(function(){

  var offBulb = "https://s3.amazonaws.com/codecademy-content/programs/code-foundations-path/bop-i/boolean/lightbulb_off.png";
  var onBulb = "https://s3.amazonaws.com/codecademy-content/programs/code-foundations-path/bop-i/boolean/lightbulb_on.png";

  var $lightBulb = $("img#lightBulb");
  var $booleanButton = $("button#booleanButton");

  // When we click the boolean button, run a function
  $booleanButton.click(function(){
    // cache the jquery $(this) keyword because we use it repeatedly
    var $this = $(this);
    // toggle the class of the boolean button so we can alter the text according to if it's on or off
    $this.toggleClass("off");
    // if the thing we just clicked on has the class of off, we need to give the option to turn on
    // and offer that option accordingly in the text "turn on!"
    // and make sure that the lightbulb is off via the src because how could we turn a bulb on
    // that's already on?
    // and vice versa... I hope this is enough explanation
    if( $this.hasClass("off") ) {
      $this.text("Turn the lightbulb on!");
      $lightBulb.attr("src", offBulb);
    } else {
      $this.text("Turn the lightbulb off!");
      $lightBulb.attr("src", onBulb);
    }
  });


});
