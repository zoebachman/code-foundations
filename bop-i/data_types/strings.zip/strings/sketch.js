// user should be able to see the word hello
// hello is represented as a string of flags, each flag containing a letter
// rotate them so the look like they're hanging - figure out how rotation actually works
// make them look like they're on a string
// change the colors - so each has it's own color
// to make interactive: they input a word (less than 10 letters) and it appears on the flags
// go through a sequence of colors

var input; //, button, greeting;

function setup() {
  createCanvas(windowWidth, windowHeight); //should figure out how to change this to variable width

  input = createInput('string!');
  input.position(20, height);

  textAlign(CENTER);
  textSize(50);

}

function draw() {
  background("white");
  drawFlags();
}


function drawFlags() {
  var myWord = input.value();

  myWord = myWord.toUpperCase();

  var characters = myWord.split("");

  noFill();
  stroke(4);

  var stringHeight = -340;

// change string width and height depending on number of characters
  // if (characters.length > 10) {
  //   ellipse(width / 2, stringHeight + 80, 900);
  // } else if (characters.length > 8) {
  //   ellipse(width / 2, stringHeight + 50, 900);
  // } else if (characters.length > 5) {
  //   ellipse(width / 2, stringHeight + 30, 900);
  // } else {
  //   ellipse(width / 2, stringHeight, 900);
  // }

  // draw an ellipse (the "string") based on the number of characters
  ellipse(width/2, (stringHeight + (characters.length*6)), 1200 + (characters.length*9), 950);

  // flag colors
  var blue = [157, 192, 249];
  var pink = "pink";
  var green = [152, 251, 152];
  var yellow = [249, 236, 157];
  var colorCount = 0; // how to keep track of colors used

  // numbers to keep track of flag number and positions
  var flagHeights = [];
  var j = 0; // to keep track of heights
  var counter = 1; // to create heights


  for (var i = 0; i < characters.length; i++) {
    // create a new flag
    flag[i] = new flag();
    var colors = [blue, pink, green, yellow];

    // give the flag a new color
    flag[i].col = colors[colorCount];

    console.log(colorCount);

    colorCount++;

    if (colorCount == 4){
      colorCount = 0;
    }

    // modify flag x position
    flag[i].x = (60 * (i + 1)) + (width / 2 - ((Math.round(characters.length / 2) * 70)));


    if (characters.length % 2 == 1) { // if characters are an odd number

      if (i < Math.round(characters.length / 2)) {

        flagHeights.push((counter * 5) + 130);
        flag[i].y = flagHeights[j];

        counter += 2;
        j++;

      } else if (i == Math.round(characters.length / 2)) {
        j -= 2;
        flag[i].y = flagHeights[j];
        //console.log(flagHeights);


      } else if (i > Math.round(characters.length / 2)) {
        j--;
        flag[i].y = flagHeights[j];
      }

      flag[i].letter = characters[i];

      // update display
      flag[i].display();

    } else { //for even numbers
      if (i < Math.round(characters.length / 2)) {

        flagHeights.push((counter * 5) + 130);
        flag[i].y = flagHeights[j];

        counter += 2;

        j++;
      } else if (i >= Math.round(characters.length / 2)) {
        j--;
        flag[i].y = flagHeights[j];
      }

      flag[i].letter = characters[i];

      // update display
      flag[i].display();
    }
  }
}

// flag object

class flag {
  constructor(x, y, letter) {
    this.x = width / 2;
    this.y = 100;//height / 2;
    this.col = [157, 192, 249];
    this.w = 55;
    this.h = 75;
    this.letter = "H";
  }

  display(){
    noStroke();
    fill(this.col);
    rect(this.x, this.y, this.w, this.h);

    fill("white");
    textSize(45);
    text(this.letter, this.x + 30, this.y + 55);
  }
}
